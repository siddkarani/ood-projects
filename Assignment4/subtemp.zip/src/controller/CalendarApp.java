package controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import model.Calendars;
import model.MultipleCalendars;
import view.View;
import view.ViewForConsole;

/**
 * Main application class for the Calendar application. Represents a Calendar App that can
 * be run in either interactive or headless mode (with a txt file).
 */
public class CalendarApp {

  /**
   * Entry point for the CalendarApp.
   * Supports both interactive and headless modes.
   *
   * @param args command line arguments specifying mode and optional file
   */
  public static void main(String[] args) {
    try {
      validateArguments(args);
      View view = new ViewForConsole();
      Calendars calendars = new MultipleCalendars(view);
      EnhancedCommandParser parser = new EnhancedCommandParser(calendars, view);

      String mode = args[1].toLowerCase();

      // delegate to appropriate method based on mode argument
      if ("interactive".equals(mode)) {
        runInteractiveMode(parser, view);
      } else if ("headless".equals(mode)) {
        if (args.length < 3) {
          throw new IllegalArgumentException("Headless mode requires a filename");
        }
        runHeadlessMode(parser, args[2], view);
      } else {
        throw new IllegalArgumentException("Invalid mode: " + mode);
      }
    } catch (Exception e) {
      System.err.println("Error: " + e.getMessage());
      printUsage();
    }
  }

  /**
   * Validates command line arguments.
   * @param args the command line arguments to validate
   * @throws IllegalArgumentException  throws an exception if invalid
   */
  private static void validateArguments(String[] args) throws IllegalArgumentException {
    if (args.length < 2 || !args[0].equalsIgnoreCase("--mode")) {
      throw new IllegalArgumentException("Invalid arguments");
    }
  }

  /**
   * Prints usage information.
   */
  private static void printUsage() {
    System.out.println("Usage: java CalendarApp --mode [interactive|headless commands.txt]");
  }

  /**
   * Runs the application in interactive mode.
   *
   * @param parser the command parser to use
   * @param view the view for displaying output
   */
  public static void runInteractiveMode(EnhancedCommandParser parser, View view) {
    if (parser == null || view == null) {
      throw new IllegalArgumentException("Parser and view cannot be null");
    }

    try (Scanner scanner = new Scanner(System.in)) {
      view.displayMessage("Calendar Application - Interactive Mode");
      view.displayMessage("Type 'exit' to quit");

      while (true) {
        view.displayMessage("> ");

        if (!scanner.hasNextLine()) {
          break;
        }

        String command = scanner.nextLine().trim();

        if (command.isEmpty()) {
          continue;
        }

        // executes the command and displays the result
        String result = parser.executeCommand(command);
        view.displayMessage(result);

        if (command.equalsIgnoreCase("exit")) {
          break;
        }
      }
    } catch (Exception e) {
      view.displayError("Error in interactive mode: " + e.getMessage());
    }
  }

  /**
   * Runs the Calendar in headless mode.
   *
   * @param parser the command parser to use
   * @param filename the file containing commands
   * @param view the view for displaying output
   * @throws IOException if file operations fail
   */
  public static void runHeadlessMode(EnhancedCommandParser parser, String filename, View view)
          throws IOException {
    if (parser == null || filename == null || view == null) {
      throw new IllegalArgumentException("Parser, filename, and view cannot be null");
    }

    // reads the file and runs the commands, then sends the output to view
    try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
      String command;
      boolean foundExit = false;

      while ((command = reader.readLine()) != null) {
        command = command.trim();

        if (command.isEmpty()) {
          continue;
        }

        String result = parser.executeCommand(command);
        view.displayMessage(result);

        if (command.equalsIgnoreCase("exit")) {
          foundExit = true;
          break;
        }
      }

      if (!foundExit) {
        throw new IllegalStateException("There is no exit command in this file.");
      }
    } catch (IOException e) {
      throw new IOException("Error reading file: " + filename, e);
    }
  }
}