package model;

import java.time.LocalDateTime;
import java.util.Objects;

public abstract class AbstractEvent implements IEvent {
  protected final String subject;
  protected final LocalDateTime startDateTime;
  protected final LocalDateTime endDateTime;
  protected final String description;
  protected final String location;
  protected final String status;
  protected String seriesId;

  AbstractEvent(String subject, LocalDateTime startDateTime, LocalDateTime endDateTime,
                 String description, String location, String status, String seriesId) {
    this.subject = subject;
    this.startDateTime = startDateTime;
    this.endDateTime = endDateTime;
    this.description = description;
    this.location = location;
    this.status = status;
    this.seriesId = seriesId;
  }

  public String getSubject() {
    return subject;
  }

  public LocalDateTime getStartDateTime() {
    return startDateTime;
  }

  public LocalDateTime getEndDateTime() {
    return endDateTime;
  }

  public String getDescription() {
    return description;
  }

  public String getLocation() {
    return location;
  }

  public String getStatus() {
    return status;
  }

  @Override
  public String getSeriesId() {
    return seriesId;
  }

  @Override
  public boolean isPartOfSeries() {
    return seriesId != null && !seriesId.isEmpty();
  }


}
