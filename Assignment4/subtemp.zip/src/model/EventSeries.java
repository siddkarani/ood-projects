package model;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class EventSeries extends AbstractEvent {
  private final String weekdays;
  private final LocalDateTime seriesEndDate;
  private final int occurrences;

  private EventSeries(EventSeriesBuilder builder) {
    super(builder.subject,
            builder.startDateTime,
            builder.endDateTime,
            builder.description,
            builder.location,
            builder.status,
            null);
    this.weekdays = builder.weekdays;
    this.seriesEndDate = builder.seriesEndDate;
    this.occurrences = builder.occurrences;
    this.seriesId = generateSeriesId();
  }

  private String generateSeriesId() {
    return String.format("%s-%s-%s",
            getSubject(),
            getStartDateTime().toString(),
            UUID.randomUUID().toString().substring(0, 12));
  }

  public List<Event> generateSeriesEvents() {
    List<Event> events = new ArrayList<>();
    LocalDateTime currentStart = getStartDateTime();
    LocalDateTime currentEnd = getEndDateTime();
    int count = 0;

    // keep adding the event to list until done
    while ((seriesEndDate == null || !currentStart.isAfter(seriesEndDate))
            && (occurrences == -1 || count < occurrences)) {

      if (isWeekdayMatch(currentStart.getDayOfWeek())) {
        Event event = Event.getBuilder(getSubject(), currentStart)
                .endDateTime(currentEnd)
                .description(getDescription())
                .location(getLocation())
                .status(getStatus())
                .seriesId(this.seriesId)
                .build();
        events.add(event);
        count++;
      }

      currentStart = currentStart.plusDays(1);
      currentEnd = currentEnd.plusDays(1);
    }

    return events;
  }

  private boolean isWeekdayMatch(DayOfWeek day) {
    return weekdays.chars()
            .mapToObj(c -> Weekday.fromChar((char) c))
            .anyMatch(w -> w.toJavaDayOfWeek() == day);
  }

  @Override
  public Event copyEventToNewDate(LocalDateTime start, LocalDateTime end) {
    return Event.getBuilder(getSubject(), start)
            .endDateTime(end)
            .description(getDescription())
            .location(getLocation())
            .status(getStatus())
            .seriesId(getSeriesId())
            .build();
  }

  public static EventSeriesBuilder getBuilder(String subject, LocalDateTime startDateTime) {
    return new EventSeriesBuilder(subject, startDateTime);
  }

  public static class EventSeriesBuilder {
    private final String subject;
    private LocalDateTime startDateTime;
    private LocalDateTime endDateTime;
    private String description = "";
    private String location = "";
    private String status = "CONFIRMED";
    private String weekdays;
    private LocalDateTime seriesEndDate;
    private int occurrences = -1;

    public EventSeriesBuilder(String subject, LocalDateTime startDateTime) {
      if (subject == null || subject.trim().isEmpty()) {
        throw new IllegalArgumentException("Subject cannot be null or empty");
      }
      if (startDateTime == null) {
        throw new IllegalArgumentException("Start date time cannot be null");
      }
      this.subject = subject;
      this.startDateTime = startDateTime;
    }

    public EventSeriesBuilder endDateTime(LocalDateTime endDateTime) {
      this.endDateTime = endDateTime;
      return this;
    }

    public EventSeriesBuilder description(String description) {
      this.description = description;
      return this;
    }

    public EventSeriesBuilder location(String location) {
      this.location = location;
      return this;
    }

    public EventSeriesBuilder status(String status) {
      this.status = status;
      return this;
    }

    public EventSeriesBuilder weekdays(String weekdays) {
      this.weekdays = weekdays;
      return this;
    }

    public EventSeriesBuilder seriesEndDate(LocalDateTime seriesEndDate) {
      this.seriesEndDate = seriesEndDate;
      return this;
    }

    public EventSeriesBuilder occurrences(int occurrences) {
      this.occurrences = occurrences;
      return this;
    }

    public EventSeries build() {
      // make sure weekdays are valid
      if (weekdays == null || weekdays.isEmpty()) {
        throw new IllegalArgumentException("Weekdays must be specified for series");
      }
      Weekday.validateWeekdays(weekdays);

      // make sure at least end date or n is inputted
      if (seriesEndDate == null && occurrences == -1) {
        throw new IllegalArgumentException("Either end date or number of occurrences must be specified");
      }
      if (seriesEndDate != null && seriesEndDate.isBefore(startDateTime)) {
        throw new IllegalArgumentException("End date must be after start date");
      }
      if (occurrences != -1 && occurrences <= 0) {
        throw new IllegalArgumentException("Number of occurrences must be positive");
      }

      if (endDateTime == null) {
        this.endDateTime = LocalDateTime.of(startDateTime.toLocalDate(),
                LocalTime.of(17, 0));
        this.startDateTime = LocalDateTime.of(startDateTime.toLocalDate(),
                LocalTime.of(8, 0));

        // make sure start and end date are valid
        if (endDateTime.isBefore(startDateTime)) {
          throw new IllegalArgumentException("End time cannot be before start time");
        }
        if (!startDateTime.toLocalDate().equals(endDateTime.toLocalDate())) {
          throw new IllegalArgumentException("Series events must start and end on the same day");
        }
      }
      return new EventSeries(this);
    }
  }
}