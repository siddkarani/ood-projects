package controller;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import model.Calendars;
import model.Event;
import view.View;

/**
 * Enhanced CommandParser that adds support for multiple calendars, timezones, and advanced event copying.
 * Uses composition instead of inheritance to handle both single calendar and multi-calendar commands.
 */
public class EnhancedCommandParser implements Command {

  // Event command patterns
  private static final Pattern CREATE_EVENT_PATTERN = Pattern.compile(
          "create event (\"[^\"]+\"|\\S+) from (\\S+) to (\\S+)(?:\\s+repeats\\s+(\\S+)" +
                  "(?:\\s+for\\s+(\\d+)\\s+times|\\s+until\\s+(\\S+)))?");
  private static final Pattern CREATE_ALL_DAY_PATTERN = Pattern.compile(
          "create event (\"[^\"]+\"|\\S+) on (\\S+)(?:\\s+repeats\\s+(\\S+)" +
                  "(?:\\s+for\\s+(\\d+)\\s+times|\\s+until\\s+(\\S+)))?");
  private static final Pattern EDIT_EVENT_PATTERN = Pattern.compile(
          "edit (event|events|series) (\\S+) (\"[^\"]+\"|\\S+) from (\\S+)" +
                  "(?: to (\\S+))? with (.+)");
  private static final Pattern PRINT_EVENTS_PATTERN = Pattern.compile(
          "print events(?: on (\\S+)|\\s+from\\s+(\\S+)\\s+to\\s+(\\S+))");
  private static final Pattern SHOW_STATUS_PATTERN = Pattern.compile(
          "show status on (\\S+)");

  // Calendar management patterns
  private static final Pattern CREATE_CALENDAR_PATTERN = Pattern.compile(
          "create calendar --name (\\S+) --timezone ([\\w/_-]+)");
  private static final Pattern EDIT_CALENDAR_PATTERN = Pattern.compile(
          "edit calendar --name (\\S+) --property (\\S+) (\\S+)");
  private static final Pattern USE_CALENDAR_PATTERN = Pattern.compile(
          "use calendar --name (\\S+)");
  private static final Pattern COPY_EVENT_PATTERN = Pattern.compile(
          "copy event (\"[^\"]+\"|\\S+) on (\\S+) --target (\\S+) to (\\S+)");
  private static final Pattern COPY_EVENTS_ON_PATTERN = Pattern.compile(
          "copy events on (\\S+) --target (\\S+) to (\\S+)");
  private static final Pattern COPY_EVENTS_BETWEEN_PATTERN = Pattern.compile(
          "copy events between (\\S+) and (\\S+) --target (\\S+) to (\\S+)");

  private final Calendars calendars;
  private final View view;

  /**
   * Creates an EnhancedCommandParser with the specified calendars system and view.
   *
   * @param calendars the calendars system to operate on
   * @param view      the view for displaying results
   * @throws IllegalArgumentException if either argument is null
   */
  public EnhancedCommandParser(Calendars calendars, View view) throws IllegalArgumentException {
    if (calendars == null) {
      throw new IllegalArgumentException("Calendar cannot be null");
    }
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }
    this.calendars = calendars;
    this.view = view;
  }

  /**
   * Executes a command and returns a result message.
   * Handles both calendar-specific commands and regular event commands.
   *
   * @param command the command to be executed
   * @return a string response to the command
   * @throws IllegalArgumentException if the command is null or empty
   */
  @Override
  public String executeCommand(String command) throws IllegalArgumentException {
    if (command == null || command.trim().isEmpty()) {
      return "Error: Command cannot be null or empty";
    }

    String trimmedCommand = command.trim();

    try {
      if (trimmedCommand.equalsIgnoreCase("exit")) {
        return "Exiting...";
      }

      // Handle calendar-specific commands first
      if (trimmedCommand.startsWith("create calendar")) {
        return handleCreateCalendarCommand(trimmedCommand);
      } else if (trimmedCommand.startsWith("edit calendar")) {
        return handleEditCalendarCommand(trimmedCommand);
      } else if (trimmedCommand.startsWith("use calendar")) {
        return handleUseCalendarCommand(trimmedCommand);
      } else if (trimmedCommand.startsWith("copy events")) {
        return handleCopyEventsCommand(trimmedCommand);
      } else if (trimmedCommand.startsWith("copy event")) {
        return handleCopyEventCommand(trimmedCommand);
      }

      // Handle regular event commands
      if (trimmedCommand.startsWith("create event")) {
        return handleCreateCommand(trimmedCommand);
      } else if (trimmedCommand.startsWith("edit")) {
        return handleEditCommand(trimmedCommand);
      } else if (trimmedCommand.startsWith("print events")) {
        return handlePrintCommand(trimmedCommand);
      } else if (trimmedCommand.startsWith("show status")) {
        return handleStatusCommand(trimmedCommand);
      } else {
        throw new IllegalArgumentException("Not a valid command: " + command);
      }
    } catch (Exception e) {
      view.displayError(e.getMessage());
      return "Error: " + e.getMessage();
    }
  }

  /**
   * Handles create calendar commands.
   */
  private String handleCreateCalendarCommand(String command) throws IllegalArgumentException {
    Matcher matcher = CREATE_CALENDAR_PATTERN.matcher(command);
    if (!matcher.matches()) {
      throw new IllegalArgumentException("Invalid create calendar format");
    }

    String calendarName = matcher.group(1);
    String timezoneId = matcher.group(2);

    TimeZone timezone = TimeZone.getTimeZone(timezoneId);
    calendars.createCalendar(calendarName, timezone);
    return "Calendar '" + calendarName + "' created successfully";
  }

  /**
   * Handles edit calendar commands.
   */
  private String handleEditCalendarCommand(String command) throws IllegalArgumentException {
    Matcher matcher = EDIT_CALENDAR_PATTERN.matcher(command);
    if (!matcher.matches()) {
      throw new IllegalArgumentException("Invalid edit calendar format");
    }

    String calendarName = matcher.group(1);
    String property = matcher.group(2);
    String newValue = matcher.group(3);

    calendars.editCalendar(calendarName, property, newValue);
    return "Calendar '" + calendarName + "' updated successfully";
  }

  /**
   * Handles use calendar commands to set the active calendar.
   */
  private String handleUseCalendarCommand(String command) throws IllegalArgumentException {
    Matcher matcher = USE_CALENDAR_PATTERN.matcher(command);
    if (!matcher.matches()) {
      throw new IllegalArgumentException("Invalid use calendar format");
    }

    String calendarName = matcher.group(1);
    calendars.useCalendar(calendarName);
    return "Now using calendar: " + calendarName;
  }

  /**
   * Handles copy event commands.
   */
  private String handleCopyEventCommand(String command) throws IllegalArgumentException {
    Matcher matcher = COPY_EVENT_PATTERN.matcher(command);
    if (!matcher.matches()) {
      throw new IllegalArgumentException("Invalid copy event format");
    }

    String eventName = extractSubject(matcher.group(1));
    LocalDateTime originalDateTime = parseDateTime(matcher.group(2));
    String targetCalendar = matcher.group(3);
    LocalDateTime newDateTime = parseDateTime(matcher.group(4));

    calendars.copyEvent(eventName, originalDateTime, targetCalendar, newDateTime);
    return "Event copied successfully";
  }

  /**
   * Handles copy events commands.
   */
  private String handleCopyEventsCommand(String command) throws IllegalArgumentException {
    Matcher matcher = COPY_EVENTS_ON_PATTERN.matcher(command);
    if (matcher.matches()) {
      String sourceDate = matcher.group(1);
      String targetCalendar = matcher.group(2);
      String targetDate = matcher.group(3);

      calendars.copyEventsOn(sourceDate, targetCalendar, targetDate);
      return "Events copied successfully";
    }

    matcher = COPY_EVENTS_BETWEEN_PATTERN.matcher(command);
    if (matcher.matches()) {
      String startDate = matcher.group(1);
      String endDate = matcher.group(2);
      String targetCalendar = matcher.group(3);
      String targetDate = matcher.group(4);

      calendars.copyEventsBetween(startDate, endDate, targetCalendar, targetDate);
      return "Events copied successfully";
    }

    throw new IllegalArgumentException("Invalid format for copy events command");
  }

  /**
   * Handles event creation commands. Sees if the input matches any of these patterns.
   */
  private String handleCreateCommand(String command) throws IllegalArgumentException {
    // timed event first
    Matcher matcher = CREATE_EVENT_PATTERN.matcher(command);
    if (matcher.matches()) {
      return handleTimedEventCreation(matcher);
    }

    // all-day event
    matcher = CREATE_ALL_DAY_PATTERN.matcher(command);
    if (matcher.matches()) {
      return handleAllDayEventCreation(matcher);
    }

    throw new IllegalArgumentException("Invalid create format");
  }

  /**
   * Handles creation of timed events.
   */
  private String handleTimedEventCreation(Matcher matcher) {
    String subject = extractSubject(matcher.group(1));
    LocalDateTime start = parseDateTime(matcher.group(2));
    LocalDateTime end = parseDateTime(matcher.group(3));
    String weekdays = matcher.group(4);
    String timesStr = matcher.group(5);
    String untilStr = matcher.group(6);

    Event event = Event.getBuilder(subject, start)
            .endDateTime(end)
            .build();

    if (weekdays == null) {
      calendars.createEvent(event);
    } else if (timesStr != null) {
      calendars.createEventSeriesNTimes(event, weekdays, Integer.parseInt(timesStr));
    } else if (untilStr != null) {
      calendars.createEventSeriesUntil(event, weekdays, untilStr);
    }

    return "This event was created successfully";
  }

  /**
   * Handles creation of all-day events.
   */
  private String handleAllDayEventCreation(Matcher matcher) {
    String subject = extractSubject(matcher.group(1));
    String dateStr = matcher.group(2);
    String weekdays = matcher.group(3);
    String timesStr = matcher.group(4);
    String untilStr = matcher.group(5);

    // creates an all day event 8am-5pm
    LocalDateTime start = LocalDateTime.of(LocalDateTime.parse(dateStr + "T00:00").toLocalDate(),
            LocalTime.of(8, 0));
    LocalDateTime end = LocalDateTime.of(LocalDateTime.parse(dateStr + "T00:00").toLocalDate(),
            LocalTime.of(17, 0));

    Event event = Event.getBuilder(subject, start)
            .endDateTime(end)
            .build();
    // singular event
    if (weekdays == null) {
      calendars.createEvent(event);
    }
    // means that this is a series with n repeats
    else if (timesStr != null) {
      calendars.createEventSeriesNTimes(event, weekdays, Integer.parseInt(timesStr));
    }
    // means that this is a series with until a certain date/time
    else if (untilStr != null) {
      calendars.createEventSeriesUntil(event, weekdays, untilStr + "T00:00");
    }

    return "This all-day event was created successfully";
  }

  /**
   * Handles edit commands.
   */
  private String handleEditCommand(String command) throws IllegalArgumentException {
    Matcher matcher = EDIT_EVENT_PATTERN.matcher(command);
    if (!matcher.matches()) {
      throw new IllegalArgumentException("Invalid edit format");
    }

    String editType = matcher.group(1);
    String property = matcher.group(2);
    String subject = extractSubject(matcher.group(3));
    String startDateTime = matcher.group(4);
    String endDateTime = matcher.group(5);
    String newValue = matcher.group(6);

    // delegates to the right method based on edit type
    switch (editType.toLowerCase()) {
      case "event":
        calendars.editEvent(property, subject, startDateTime, endDateTime, newValue);
        break;
      case "events":
        calendars.editEvents(property, subject, startDateTime, newValue);
        break;
      case "series":
        calendars.editEventSeries(property, subject, startDateTime, newValue);
        break;
      default:
        throw new IllegalArgumentException("Invalid edit type: " + editType);
    }

    return "Event(s) edited successfully";
  }

  /**
   * Handles print commands.
   */
  private String handlePrintCommand(String command) throws IllegalArgumentException {
    Matcher matcher = PRINT_EVENTS_PATTERN.matcher(command);
    if (!matcher.matches()) {
      throw new IllegalArgumentException("Invalid print format");
    }

    String singleDate = matcher.group(1);
    if (singleDate != null) {
      return calendars.daySchedule(singleDate);
    } else {
      String startTime = matcher.group(2);
      String endTime = matcher.group(3);
      if (startTime == null || endTime == null) {
        throw new IllegalArgumentException("Invalid date range format");
      }
      return calendars.rangeSchedule(startTime, endTime);
    }
  }

  /**
   * Handles show status commands.
   */
  private String handleStatusCommand(String command) throws IllegalArgumentException {
    Matcher matcher = SHOW_STATUS_PATTERN.matcher(command);
    if (!matcher.matches()) {
      throw new IllegalArgumentException("Invalid status format");
    }
    return calendars.isFree(matcher.group(1));
  }

  /**
   * Extracts subject from quoted or unquoted string.
   */
  private String extractSubject(String subject) {
    if (subject == null) {
      throw new IllegalArgumentException("Subject cannot be null");
    }
    if (subject.startsWith("\"") && subject.endsWith("\"") && subject.length() > 1) {
      return subject.substring(1, subject.length() - 1);
    }
    return subject;
  }

  /**
   * Parses date-time string to LocalDateTime.
   */
  private LocalDateTime parseDateTime(String dateTime) {
    if (dateTime == null) {
      throw new IllegalArgumentException("DateTime cannot be null");
    }
    try {
      return LocalDateTime.parse(dateTime);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid date-time format: " + dateTime);
    }
  }
}