package model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import view.View;

public class TimezoneCalendar extends SingleCalendar {
  TimeZone timeZone;

  public TimezoneCalendar(View view, TimeZone timeZone) {
    super(view);
    this.timeZone = timeZone;
  }


  public void updateTimes(TimeZone newTimeZone) {
    // Check for invalid timezone conversion
    if (newTimeZone.getID().equals("GMT") && !newTimeZone.toString().equals("GMT")) {
      throw new IllegalArgumentException("Invalid timezone");
    }

    TimeZone oldTimeZone = this.timeZone;
    List<Event> allEvents = new ArrayList<>();

    // First, collect all events
    for (List<Event> events : eventsByStartDate.values()) {
      allEvents.addAll(events);
    }

    // Clear all existing events
    eventsByStartDate.clear();

    // Update timezone
    this.timeZone = newTimeZone;

    // Add each event back with converted times
    for (Event event : allEvents) {
      LocalDateTime newStart = event.getStartDateTime()
              .atZone(oldTimeZone.toZoneId())
              .withZoneSameInstant(newTimeZone.toZoneId())
              .toLocalDateTime();

      LocalDateTime newEnd = event.getEndDateTime()
              .atZone(oldTimeZone.toZoneId())
              .withZoneSameInstant(newTimeZone.toZoneId())
              .toLocalDateTime();

      Event updatedEvent = Event.getBuilder(event.getSubject(), newStart)
              .endDateTime(newEnd)
              .description(event.getDescription())
              .location(event.getLocation())
              .status(event.getStatus())
              .seriesId(event.getSeriesId())
              .build();

      eventsByStartDate.computeIfAbsent(newStart, k -> new ArrayList<>()).add(updatedEvent);

    }
  }
}