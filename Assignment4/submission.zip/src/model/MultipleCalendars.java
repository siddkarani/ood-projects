package model;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import view.View;

/**
 * Represents the model for an application that can handle having more than one Calendar.
 */
public class MultipleCalendars implements Calendars {
  private final Map<String, TimezoneCalendar> calendarsByName;
  private final View view;
  private TimezoneCalendar currentCalendar;

  public MultipleCalendars(View view) {
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }
    this.calendarsByName = new HashMap<>();
    this.view = view;
  }

  @Override
  public void createCalendar(String calendarName, TimeZone timezone) {
    if (calendarsByName.containsKey(calendarName)) {
      throw new IllegalArgumentException("A calendar with this name already exists");
    }
    if (timezone.getID().equals("GMT") && !timezone.toString().equals("GMT")) {
      throw new IllegalArgumentException("Invalid timezone");
    }

    TimezoneCalendar newCalendar = new TimezoneCalendar(this.view, timezone);
    calendarsByName.putIfAbsent(calendarName, newCalendar);

  }


  @Override
  public void editCalendar(String name, String property, String newValue) {
    CalendarsProperty calendarsProperty = CalendarsProperty.fromString(property);

    TimezoneCalendar calendarToChange = calendarsByName.get(name);
    if (calendarToChange == null) {
      throw new IllegalArgumentException("Calendar not found");
    }

    switch (calendarsProperty) {
      case NAME:
        if (calendarsByName.containsKey(newValue)) {
          throw new IllegalArgumentException("A calendar with this name already exists");
        }
        calendarsByName.remove(name);
        calendarsByName.put(newValue, calendarToChange);
        break;

      case TIMEZONE:
        TimeZone newTimeZone = TimeZone.getTimeZone(newValue);
        // means that the timezone couldnt be parsed
        // got GMT but it wasnt GMT - > invalid
        if (newTimeZone.getID().equals("GMT") && !newValue.equals("GMT")) {
          throw new IllegalArgumentException("Invalid timezone");
        }
        calendarToChange.updateTimes(newTimeZone);
        break;

      default:
        throw new IllegalArgumentException("Invalid property");
    }
  }

  @Override
  public void useCalendar(String name) {
    TimezoneCalendar calendar = calendarsByName.get(name);
    if (calendar == null) {
      throw new IllegalArgumentException("Calendar not found");
    }
    this.currentCalendar = calendar;
  }


  private void validateCurrentCalendar() {
    if (currentCalendar == null) {
      throw new IllegalStateException("No calendar currently in use");
    }
  }

  private TimezoneCalendar validateTargetCalendar(String calendarName) {
    if (!calendarsByName.containsKey(calendarName)) {
      throw new IllegalArgumentException("No calendar found with that name");
    }
    return calendarsByName.get(calendarName);
  }

  @Override
  public void copyEvent(String eventName, LocalDateTime originalDate, String calendarName, LocalDateTime newDate) {
    validateCurrentCalendar();
    TimezoneCalendar targetCalendar = validateTargetCalendar(calendarName);

    // look for the event
    List<Event> eventsByStartDate = currentCalendar.eventsByStartDate.get(originalDate);
    if (eventsByStartDate == null) {
      throw new IllegalArgumentException("No events found at the specified date and time");
    }

    Event eventToCopy = eventsByStartDate.stream()
            .filter(e -> e.getSubject().equals(eventName))
            .findFirst()
            .orElseThrow(() -> new IllegalArgumentException("Event not found"));


    // make sure right timezone is used when pasting

    Duration duration = Duration.between(eventToCopy.getStartDateTime(), eventToCopy.getEndDateTime());

    Event newEvent = Event.getBuilder(eventToCopy.getSubject(), newDate)
            .endDateTime(newDate.plus(duration))
            .description(eventToCopy.getDescription())
            .location(eventToCopy.getLocation())
            .status(eventToCopy.getStatus())
            .seriesId(eventToCopy.getSeriesId())
            .build();

    targetCalendar.createEvent(newEvent);
  }


  @Override
  public void copyEventsOn(String originalDate, String calendarName, String newDate) {
    validateCurrentCalendar();
    TimezoneCalendar targetCalendar = validateTargetCalendar(calendarName);

    // parse original and new dates
    LocalDate originalLocalDate = LocalDate.parse(originalDate);
    LocalDate newTargetLocalDate = LocalDate.parse(newDate);

    // gets events from the original date
    List<Event> eventsOnDay = new ArrayList<>();
    for (List<Event> eventList : currentCalendar.eventsByStartDate.values()) {
      for (Event event : eventList) {
        LocalDate eventStartDate = event.getStartDateTime().toLocalDate();
        LocalDate eventEndDate = event.getEndDateTime().toLocalDate();

        // Add if the event occurs on or spans the original date
        if ((eventStartDate.isEqual(originalLocalDate) || eventStartDate.isBefore(originalLocalDate)) &&
                (eventEndDate.isEqual(originalLocalDate) || eventEndDate.isAfter(originalLocalDate))) {
          eventsOnDay.add(event);
        }
      }
    }

    // throw if no events found
    if (eventsOnDay.isEmpty()) {
      throw new IllegalArgumentException("No events found on this day");
    }

    // coppies each event to the target calendar with adjusted times
    for (Event eventToCopy : eventsOnDay) {
      // Combine the new date with the event's start and end times
      LocalDateTime startDateTimeAdjustedToNewDate = LocalDateTime.of(newTargetLocalDate, eventToCopy.getStartDateTime().toLocalTime());
      LocalDateTime endDateTimeAdjustedToNewDate = LocalDateTime.of(newTargetLocalDate, eventToCopy.getEndDateTime().toLocalTime());

      // converts the event's times to the target calendar's timezone
      LocalDateTime convertedStartDateTime = startDateTimeAdjustedToNewDate
              .atZone(currentCalendar.timeZone.toZoneId())
              .withZoneSameInstant(targetCalendar.timeZone.toZoneId())
              .toLocalDateTime();
      LocalDateTime convertedEndDateTime = endDateTimeAdjustedToNewDate
              .atZone(currentCalendar.timeZone.toZoneId())
              .withZoneSameInstant(targetCalendar.timeZone.toZoneId())
              .toLocalDateTime();

      // create a new event in the target calendar with converted times
      Event newEvent = Event.getBuilder(eventToCopy.getSubject(), convertedStartDateTime)
              .endDateTime(convertedEndDateTime)
              .description(eventToCopy.getDescription())
              .location(eventToCopy.getLocation())
              .status(eventToCopy.getStatus())
              .seriesId(eventToCopy.getSeriesId())
              .build();

      targetCalendar.createEvent(newEvent);
    }

  }

  @Override
  public void copyEventsBetween(String startDate, String endDate, String calendarName, String newDate) {
    validateCurrentCalendar();
    TimezoneCalendar targetCalendar = validateTargetCalendar(calendarName);


    // parse start, end, and target dates
    LocalDate startLocalDate = LocalDate.parse(startDate);
    LocalDate endLocalDate = LocalDate.parse(endDate);
    LocalDate targetLocalDate = LocalDate.parse(newDate);

    if (endLocalDate.isBefore(startLocalDate)) {
      throw new IllegalArgumentException("End date must not be before start date");
    }

    // collect all events within the specified date range
    List<Event> eventsInRange = currentCalendar.findEventsInRange(
            startLocalDate.atStartOfDay(),
            endLocalDate.atTime(LocalTime.MAX)
    );

    if (eventsInRange.isEmpty()) {
      throw new IllegalArgumentException("No events found in this range of times");
    }

    // offset for mapping the start date of range to the target date
    long daysOffset = ChronoUnit.DAYS.between(startLocalDate, targetLocalDate);

    // copy events and using correct timezones
    for (Event eventToCopy : eventsInRange) {
      // Calculate new start and end times, shifted by the target offset
      LocalDateTime offsetStartDateTime = eventToCopy.getStartDateTime().plusDays(daysOffset);
      LocalDateTime offsetEndDateTime = eventToCopy.getEndDateTime().plusDays(daysOffset);

      LocalDateTime adjustedStartDateTime = offsetStartDateTime
              .atZone(currentCalendar.timeZone.toZoneId())
              .withZoneSameInstant(targetCalendar.timeZone.toZoneId())
              .toLocalDateTime();
      LocalDateTime adjustedEndDateTime = offsetEndDateTime
              .atZone(currentCalendar.timeZone.toZoneId())
              .withZoneSameInstant(targetCalendar.timeZone.toZoneId())
              .toLocalDateTime();

      // makes events with the right times
      Event copiedEvent = Event.getBuilder(eventToCopy.getSubject(), adjustedStartDateTime)
              .endDateTime(adjustedEndDateTime)
              .description(eventToCopy.getDescription())
              .location(eventToCopy.getLocation())
              .status(eventToCopy.getStatus())
              .seriesId(eventToCopy.getSeriesId())
              .build();

      // add to calendar
      targetCalendar.createEvent(copiedEvent);
    }
  }

  @Override
  public String getCalendars() {
    if (calendarsByName.isEmpty()) {
      return "No calendars";
    }
    List<String> sortedNames = new ArrayList<>(calendarsByName.keySet());
    Collections.sort(sortedNames);
    return String.join("\n", sortedNames);
  }

  @Override
  public void createEvent(Event event) {
    if (currentCalendar == null) {
      throw new IllegalStateException("No calendar selected");
    }
    currentCalendar.createEvent(event);
  }

  @Override
  public void createEventSeriesNTimes(Event event, String weekdays, int n) {
    if (currentCalendar == null) {
      throw new IllegalStateException("No calendar selected");
    }
    currentCalendar.createEventSeriesNTimes(event, weekdays, n);
  }

  @Override
  public void createEventSeriesUntil(Event event, String weekdays, String until) {
    if (currentCalendar == null) {
      throw new IllegalStateException("No calendar selected");
    }
    currentCalendar.createEventSeriesUntil(event, weekdays, until);
  }

  @Override
  public void editEvent(String property, String subject, String startDateTime, String endDateTime, String newValue) {
    if (currentCalendar == null) {
      throw new IllegalStateException("No calendar selected");
    }
    currentCalendar.editEvent(property, subject, startDateTime,endDateTime, newValue);
  }

  @Override
  public void editEvents(String property, String subject, String startDateTime, String newValue) {
    if (currentCalendar == null) {
      throw new IllegalStateException("No calendar selected");
    }
    currentCalendar.editEvents(property, subject, startDateTime, newValue);
  }

  @Override
  public void editEventSeries(String property, String subject, String startDateTime, String newValue) {
    if (currentCalendar == null) {
      throw new IllegalStateException("No calendar selected");
    }
    currentCalendar.editEventSeries(property, subject, startDateTime, newValue);
  }

  @Override
  public String daySchedule(String date) {
    if (currentCalendar == null) {
      throw new IllegalStateException("No calendar selected");
    }
    return currentCalendar.daySchedule(date);
  }

  @Override
  public String rangeSchedule(String time1, String time2) {
    if (currentCalendar == null) {
      throw new IllegalStateException("No calendar selected");
    }
    return currentCalendar.rangeSchedule(time1, time2);
  }

  @Override
  public String isFree(String date) {
    if (currentCalendar == null) {
      throw new IllegalStateException("No calendar selected");
    }
    return currentCalendar.isFree(date);
  }


}