package model;

import java.time.LocalDateTime;
import java.util.TimeZone;

public interface Calendars extends Calendar {
  void createCalendar(String calendarName, TimeZone timezone);

  void editCalendar(String name, String property, String newValue);

  void useCalendar(String name);

  void copyEvent(String eventName, LocalDateTime originalDate, String calendarName, LocalDateTime newDate);

  void copyEventsOn(String originalDate, String calendarName, String newDate);

  void copyEventsBetween(String startDate, String endDate, String calendarName, String newDate);

  String getCalendars();
}