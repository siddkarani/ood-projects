package model;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import view.View;

/**
 * Implementation of the Calendar interface that manages calendar events.
 *
 * SOLID Principles Applied:
 * - Single Responsibility: Focuses on calendar management and delegates
 *   formatting, validation, and other concerns to helper classes
 * - Open/Closed: Can be extended through composition without modification
 * - Liskov Substitution: Properly implements Calendar interface contract
 * - Interface Segregation: Implements focused Calendar interface
 * - Dependency Inversion: Depends on View abstraction, not concrete implementation
 */
public class CalendarAppModel implements Calendar {
  private final Map<LocalDateTime, List<Event>> eventsByStartDate;
  private final View view;
  private final EventValidator validator;
  private final ScheduleFormatter formatter;

  /**
   * Constructs a CalendarAppModel with the specified view.
   * Follows Dependency Inversion Principle by depending on View abstraction.
   *
   * @param view the view for displaying messages and errors
   */
  public CalendarAppModel(View view) {
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }
    this.eventsByStartDate = new HashMap<>();
    this.view = view;
    this.validator = new EventValidatorImpl();
    this.formatter = new ScheduleFormatterImpl();
  }

  @Override
  public void createEvent(Event event) {
    if (event == null) {
      throw new IllegalArgumentException("Event cannot be null");
    }

    validator.validateForCreation(event);

    if (isDuplicate(event)) {
      throw new IllegalArgumentException("An event with the same name and time already exists");
    }

    eventsByStartDate.computeIfAbsent(event.getStartDateTime(), k -> new ArrayList<>()).add(event);
  }

  @Override
  public void createEventSeriesNTimes(Event event, String weekdays, int n) {
    if (event == null) {
      throw new IllegalArgumentException("Event cannot be null");
    }

    validator.validateForSeriesCreation(event, weekdays, n);

    List<Event> eventsToCreate = generateSeriesEvents(event, weekdays, n, null);

    // Check for duplicates before creating any events
    for (Event newEvent : eventsToCreate) {
      if (isDuplicate(newEvent)) {
        throw new IllegalArgumentException("This would create a duplication");
      }
    }

    // Create all events if no duplicates found
    for (Event newEvent : eventsToCreate) {
      eventsByStartDate.computeIfAbsent(newEvent.getStartDateTime(), k -> new ArrayList<>())
              .add(newEvent);
    }
  }

  @Override
  public void createEventSeriesUntil(Event event, String weekdays, LocalDateTime until) {
    if (event == null) {
      throw new IllegalArgumentException("Event cannot be null");
    }

    validator.validateForSeriesCreation(event, weekdays, until);

    List<Event> eventsToCreate = generateSeriesEvents(event, weekdays, -1, until);

    // Check for duplicates before creating any events
    for (Event newEvent : eventsToCreate) {
      if (isDuplicate(newEvent)) {
        throw new IllegalArgumentException("This would create a duplication");
      }
    }

    // Create all events if no duplicates found
    for (Event newEvent : eventsToCreate) {
      eventsByStartDate.computeIfAbsent(newEvent.getStartDateTime(), k -> new ArrayList<>())
              .add(newEvent);
    }
  }

  @Override
  public void editEvent(String subject, String startDateTime, String endDateTime,
                        String propertyName, String newValue) {
    LocalDateTime start = LocalDateTime.parse(startDateTime);
    LocalDateTime end = LocalDateTime.parse(endDateTime);
    Property property = Property.fromString(propertyName);

    Event oldEvent = findEvent(subject, start, end);
    if (oldEvent == null) {
      throw new IllegalArgumentException("Event not found");
    }

    Event newEvent = createUpdatedEvent(oldEvent, property, newValue);
    replaceEvent(oldEvent, newEvent);
  }

  @Override
  public void editEvents(String subject, String startDateTime, String property, String newValue) {
    LocalDateTime start = LocalDateTime.parse(startDateTime);
    Property propertyToEdit = Property.fromString(property);

    List<Event> eventsToEdit = findEventsFromDate(subject, start);

    if (eventsToEdit.isEmpty()) {
      throw new IllegalArgumentException("No matching events found");
    }

    // Edit all matching events
    for (Event oldEvent : eventsToEdit) {
      Event newEvent = createUpdatedEvent(oldEvent, propertyToEdit, newValue);
      replaceEvent(oldEvent, newEvent);
    }
  }

  @Override
  public void editEventSeries(String subject, String startDateTime, String property,
                              String newProperty) {
    LocalDateTime start = LocalDateTime.parse(startDateTime);
    Property propertyToEdit = Property.fromString(property);

    // Verify the target event exists
    if (!eventExistsAt(subject, start)) {
      throw new IllegalArgumentException("Event not found");
    }

    List<Event> eventsToEdit = findAllEventsWithSubject(subject);

    // Edit all events in the series
    for (Event oldEvent : eventsToEdit) {
      Event newEvent = createUpdatedEvent(oldEvent, propertyToEdit, newProperty);
      replaceEvent(oldEvent, newEvent);
    }
  }

  @Override
  public String daySchedule(String date) {
    LocalDateTime startOfDay = LocalDateTime.parse(date + "T00:00");
    LocalDateTime endOfDay = LocalDateTime.parse(date + "T23:59:59.999999999");

    List<Event> events = findEventsInRange(startOfDay, endOfDay);
    return formatter.formatSchedule(events);
  }

  @Override
  public String rangeSchedule(String time1, String time2) {
    LocalDateTime start = LocalDateTime.parse(time1);
    LocalDateTime end = LocalDateTime.parse(time2);

    List<Event> events = findEventsInRange(start, end);
    return formatter.formatSchedule(events);
  }

  @Override
  public String isFree(String date) {
    return daySchedule(date).isEmpty() ? "Available" : "Busy";
  }

  // Private helper methods following Single Responsibility Principle

  private boolean isDuplicate(Event event) {
    List<Event> eventsAtStart = eventsByStartDate.get(event.getStartDateTime());
    if (eventsAtStart != null) {
      for (Event existingEvent : eventsAtStart) {
        if (existingEvent.getSubject().equals(event.getSubject())
                && existingEvent.getEndDateTime().equals(event.getEndDateTime())) {
          return true;
        }
      }
    }
    return false;
  }

  private List<Event> generateSeriesEvents(Event baseEvent, String weekdays, int maxCount, LocalDateTime until) {
    List<Event> events = new ArrayList<>();
    LocalDateTime start = baseEvent.getStartDateTime();
    LocalDateTime end = baseEvent.getEndDateTime();
    int count = 0;

    while ((maxCount == -1 || count < maxCount) && (until == null || !start.isAfter(until))) {
      DayOfWeek currentDayOfWeek = start.getDayOfWeek();

      if (isWeekdayMatch(currentDayOfWeek, weekdays)) {
        Event newEvent = baseEvent.copyEventToNewDate(start, end);
        events.add(newEvent);
        count++;
      }

      start = start.plusDays(1);
      end = end.plusDays(1);
    }

    return events;
  }

  private boolean isWeekdayMatch(DayOfWeek day, String weekdays) {
    for (char c : weekdays.toCharArray()) {
      if (Weekday.fromChar(c).toJavaDayOfWeek() == day) {
        return true;
      }
    }
    return false;
  }

  private Event findEvent(String subject, LocalDateTime start, LocalDateTime end) {
    List<Event> eventsAtStart = eventsByStartDate.get(start);
    if (eventsAtStart != null) {
      for (Event event : eventsAtStart) {
        if (event.getSubject().equals(subject) && event.getEndDateTime().equals(end)) {
          return event;
        }
      }
    }
    return null;
  }

  private List<Event> findEventsFromDate(String subject, LocalDateTime fromDate) {
    List<Event> events = new ArrayList<>();
    for (Map.Entry<LocalDateTime, List<Event>> entry : eventsByStartDate.entrySet()) {
      if (!entry.getKey().isBefore(fromDate)) {
        for (Event event : entry.getValue()) {
          if (event.getSubject().equals(subject)) {
            events.add(event);
          }
        }
      }
    }
    return events;
  }

  private List<Event> findAllEventsWithSubject(String subject) {
    List<Event> events = new ArrayList<>();
    for (List<Event> eventList : eventsByStartDate.values()) {
      for (Event event : eventList) {
        if (event.getSubject().equals(subject)) {
          events.add(event);
        }
      }
    }
    return events;
  }

  private boolean eventExistsAt(String subject, LocalDateTime start) {
    List<Event> eventsAtStart = eventsByStartDate.get(start);
    if (eventsAtStart != null) {
      for (Event event : eventsAtStart) {
        if (event.getSubject().equals(subject)) {
          return true;
        }
      }
    }
    return false;
  }

  private List<Event> findEventsInRange(LocalDateTime start, LocalDateTime end) {
    List<Event> events = new ArrayList<>();
    for (Map.Entry<LocalDateTime, List<Event>> entry : eventsByStartDate.entrySet()) {
      for (Event event : entry.getValue()) {
        if (!(event.getEndDateTime().isBefore(start) || event.getStartDateTime().isAfter(end))) {
          events.add(event);
        }
      }
    }
    return events;
  }

  private Event createUpdatedEvent(Event oldEvent, Property property, String newValue) {
    Event.EventBuilder builder = Event.getBuilder(oldEvent.getSubject(), oldEvent.getStartDateTime())
            .endDateTime(oldEvent.getEndDateTime())
            .description(oldEvent.getDescription())
            .location(oldEvent.getLocation())
            .status(oldEvent.getStatus());

    switch (property) {
      case SUBJECT:
        builder = Event.getBuilder(newValue, oldEvent.getStartDateTime())
                .endDateTime(oldEvent.getEndDateTime())
                .description(oldEvent.getDescription())
                .location(oldEvent.getLocation())
                .status(oldEvent.getStatus());
        break;
      case START:
        LocalDateTime newStart = LocalDateTime.parse(newValue);
        if (newStart.isAfter(oldEvent.getEndDateTime())) {
          throw new IllegalArgumentException("New end time would be after original end time");
        }
        builder = Event.getBuilder(oldEvent.getSubject(), newStart)
                .endDateTime(oldEvent.getEndDateTime())
                .description(oldEvent.getDescription())
                .location(oldEvent.getLocation())
                .status(oldEvent.getStatus());
        break;
      case END:
        LocalDateTime newEnd = LocalDateTime.parse(newValue);
        if (newEnd.isBefore(oldEvent.getStartDateTime())) {
          throw new IllegalArgumentException("End time cannot be before start time");
        }
        builder.endDateTime(newEnd);
        break;
      case DESCRIPTION:
        builder.description(newValue);
        break;
      case LOCATION:
        builder.location(newValue);
        break;
      case STATUS:
        if (!Property.isValidStatus(newValue)) {
          throw new IllegalArgumentException("Invalid status");
        }
        builder.status(newValue);
        break;
      default:
        throw new IllegalArgumentException("Invalid property");
    }

    return builder.build();
  }

  private void replaceEvent(Event oldEvent, Event newEvent) {
    removeEvent(oldEvent);
    createEvent(newEvent);
  }

  private void removeEvent(Event event) {
    List<Event> eventsAtStart = eventsByStartDate.get(event.getStartDateTime());
    if (eventsAtStart != null) {
      eventsAtStart.remove(event);
      if (eventsAtStart.isEmpty()) {
        eventsByStartDate.remove(event.getStartDateTime());
      }
    }
  }

  // Helper classes following Single Responsibility Principle

  /**
   * Validates events according to business rules.
   * Follows Single Responsibility Principle.
   */
  private static class EventValidatorImpl implements EventValidator {

    public void validateForCreation(Event event) {
      // Basic validation is handled by Event constructor
      // Additional business logic can be added here
    }

    public void validateForSeriesCreation(Event event, String weekdays, int n) {
      Weekday.validateWeekdays(weekdays);

      if (n <= 0) {
        throw new IllegalArgumentException("Number of occurrences must be positive");
      }

      if (isEventLongerThanOneDay(event)) {
        throw new IllegalArgumentException("Recurring events cannot be longer than one day");
      }
    }

    public void validateForSeriesCreation(Event event, String weekdays, LocalDateTime until) {
      Weekday.validateWeekdays(weekdays);

      if (isEventLongerThanOneDay(event)) {
        throw new IllegalArgumentException("Recurring events cannot be longer than one day");
      }

      if (!until.isAfter(event.getStartDateTime())) {
        throw new IllegalArgumentException("End date must be after start date");
      }
    }

    private boolean isEventLongerThanOneDay(Event event) {
      return !event.getStartDateTime().toLocalDate().equals(event.getEndDateTime().toLocalDate());
    }
  }

  /**
   * Formats schedule output.
   * Follows Single Responsibility Principle.
   */
  private static class ScheduleFormatterImpl implements ScheduleFormatter {
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");

    public String formatSchedule(List<Event> events) {
      if (events.isEmpty()) {
        return "";
      }

      StringBuilder schedule = new StringBuilder();
      events.sort(Comparator.comparing(Event::getStartDateTime));

      for (Event event : events) {
        schedule.append("• ").append(event.getSubject()).append(" (");

        // Format start time
        schedule.append(event.getStartDateTime().format(DATE_FORMATTER))
                .append(" ")
                .append(event.getStartDateTime().format(TIME_FORMATTER))
                .append(" - ");

        // Include end date if different from start date
        if (!event.getStartDateTime().toLocalDate().equals(event.getEndDateTime().toLocalDate())) {
          schedule.append(event.getEndDateTime().format(DATE_FORMATTER))
                  .append(" ");
        }
        schedule.append(event.getEndDateTime().format(TIME_FORMATTER))
                .append(")");

        // Add location if present
        if (!event.getLocation().isEmpty()) {
          schedule.append(" @ ").append(event.getLocation());
        }
        schedule.append("\n");
      }

      return schedule.toString();
    }
  }

  // Helper interfaces following Interface Segregation Principle

  private interface EventValidator {
    void validateForCreation(Event event);
    void validateForSeriesCreation(Event event, String weekdays, int n);
    void validateForSeriesCreation(Event event, String weekdays, LocalDateTime until);
  }

  private interface ScheduleFormatter {
    String formatSchedule(List<Event> events);
  }
}