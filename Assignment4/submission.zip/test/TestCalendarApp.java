import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import controller.CalendarApp;
import view.View;

import java.io.*;

import static org.junit.Assert.assertTrue;

public class TestCalendarApp {
  private TestView view;
  private final InputStream standardIn = System.in;
  private final PrintStream standardOut = System.out;
  private final PrintStream standardErr = System.err;
  private ByteArrayOutputStream outputStreamCaptor;
  private ByteArrayOutputStream errorStreamCaptor;

  @Before
  public void setUp() {
    view = new TestView();
    outputStreamCaptor = new ByteArrayOutputStream();
    errorStreamCaptor = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outputStreamCaptor));
    System.setErr(new PrintStream(errorStreamCaptor));
  }

  @After
  public void tearDown() {
    System.setOut(standardOut);
    System.setErr(standardErr);
    System.setIn(standardIn);
  }

  @Test
  public void testMainWithInvalidArguments() {
    String[] args = new String[]{};
    CalendarApp.main(args);

    // Check both standard error and standard output for the usage message
    String output = outputStreamCaptor.toString();
    String error = errorStreamCaptor.toString();
    String combined = output + error;

    assertTrue("Should contain usage message",
            combined.contains("Usage: java CalendarApp --mode [interactive|headless commands.txt]"));
  }

  @Test
  public void testInteractiveMode() throws Exception {
    // Set up input - need to create calendar first, then use it
    String input = "create calendar --name Test --timezone America/New_York\n" +
            "use calendar --name Test\n" +
            "create event \"Meeting\" from 2024-03-20T10:00 to 2024-03-20T11:00\n" +
            "exit\n";
    ByteArrayInputStream inputStream = new ByteArrayInputStream(input.getBytes());
    System.setIn(inputStream);

    // Run the app
    String[] args = new String[]{"--mode", "interactive"};
    CalendarApp.main(args);

    // Check output in System.out
    String output = outputStreamCaptor.toString();
    assertTrue("Should contain interactive mode message",
            output.contains("Calendar Application - Interactive Mode"));
    assertTrue("Should contain calendar created message",
            output.contains("Calendar 'Test' created successfully"));
    assertTrue("Should contain success message",
            output.contains("This event was created successfully"));
  }

  @Test
  public void testHeadlessMode() throws IOException {
    // Create temporary file
    File tempFile = File.createTempFile("test-commands", ".txt");
    try {
      // Write commands to file - need to create calendar first
      try (FileWriter writer = new FileWriter(tempFile)) {
        writer.write("create calendar --name Test --timezone America/New_York\n");
        writer.write("use calendar --name Test\n");
        writer.write("create event \"Meeting\" from 2024-03-20T10:00 to 2024-03-20T11:00\n");
        writer.write("exit\n");
      }

      // Run the app
      String[] args = new String[]{"--mode", "headless", tempFile.getAbsolutePath()};
      CalendarApp.main(args);

      // Check output
      String output = outputStreamCaptor.toString();
      assertTrue("Should contain calendar created message",
              output.contains("Calendar 'Test' created successfully"));
      assertTrue("Should contain success message",
              output.contains("This event was created successfully"));
    } finally {
      tempFile.delete();
    }
  }

  @Test
  public void testHeadlessModeWithMissingExitCommand() throws IOException {
    // Create temporary file
    File tempFile = File.createTempFile("test-commands", ".txt");
    try {
      // Write commands to file without exit
      try (FileWriter writer = new FileWriter(tempFile)) {
        writer.write("create calendar --name Test --timezone America/New_York\n");
        writer.write("use calendar --name Test\n");
        writer.write("create event \"Meeting\" from 2024-03-20T10:00 to 2024-03-20T11:00\n");
      }

      // Run the app
      String[] args = new String[]{"--mode", "headless", tempFile.getAbsolutePath()};
      CalendarApp.main(args);

      // Check both standard output and standard error for the error message
      String output = outputStreamCaptor.toString();
      String error = errorStreamCaptor.toString();
      String combined = output + error;

      assertTrue("Should contain exit command error message",
              combined.contains("There is no exit command in this file."));
    } finally {
      tempFile.delete();
    }
  }

  private static class TestView implements View {
    private final StringBuilder messages = new StringBuilder();
    private String lastError;

    @Override
    public void displayMessage(String message) {
      messages.append(message).append("\n");
    }

    @Override
    public void displayError(String error) {
      lastError = error;
    }

    public String getMessages() {
      return messages.toString();
    }

    public String getLastError() {
      return lastError;
    }
  }
}