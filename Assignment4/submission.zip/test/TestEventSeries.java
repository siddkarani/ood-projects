import org.junit.Before;
import org.junit.Test;

import java.time.LocalDateTime;

import model.Event;
import model.EventSeries;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

/**
 * Test class for EventSeries class.
 */
public class TestEventSeries {
  Event dentist;
  Event doctor;
  Event convention;

  @Before
  public void setup() {
    dentist = Event.getBuilder("Dentist Appointment",
                    LocalDateTime.parse("2025-01-01T09:00"))
            .endDateTime(LocalDateTime.parse("2025-01-01T10:00"))
            .build();
    doctor = Event.getBuilder("Doctors Appointment",
                    LocalDateTime.parse("2025-02-24T12:00"))
            .endDateTime(LocalDateTime.parse("2025-02-24T13:00"))
            .build();
    convention = Event.getBuilder("Convention",
                    LocalDateTime.parse("2025-01-03T11:00"))
            .build();
  }


}
