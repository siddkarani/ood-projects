import org.junit.Test;
import spreadsheet.MacroSpreadSheetController;
import spreadsheet.SparseSpreadSheet;
import spreadsheet.SpreadSheetWithMacro;
import spreadsheet.SpreadSheetWithMacroImpl;
import java.io.StringReader;
import static org.junit.Assert.assertTrue;

/**
 * Test class for MacroSpreadSheetController functionality.
 */
public class MacroSpreadSheetControllerTest {

  /**
   * Test bulk assign macro functionality through controller.
   */
  @Test
  public void testBulkAssignMacro() {
    StringBuilder input = new StringBuilder();
    input.append("bulk-assign-value A 1 B 2 10.5").append(System.lineSeparator());
    input.append("print-value A 1").append(System.lineSeparator());
    input.append("print-value B 2").append(System.lineSeparator());
    input.append("q").append(System.lineSeparator());

    StringBuilder output = new StringBuilder();
    SparseSpreadSheet baseSheet = new SparseSpreadSheet();
    SpreadSheetWithMacro model = new SpreadSheetWithMacroImpl(baseSheet);

    MacroSpreadSheetController controller = new MacroSpreadSheetController(
            baseSheet, new StringReader(input.toString()), output);

    controller.control();
    String result = output.toString();
    assertTrue("Should contain assigned value", result.contains("Value: 10.5"));
  }

  /**
   * Test range assign macro functionality through controller.
   */
  @Test
  public void testRangeAssignMacro() {
    StringBuilder input = new StringBuilder();
    input.append("range-assign A 1 A 3 5 2").append(System.lineSeparator());
    input.append("print-value A 1").append(System.lineSeparator());
    input.append("print-value A 2").append(System.lineSeparator());
    input.append("print-value A 3").append(System.lineSeparator());
    input.append("q").append(System.lineSeparator());

    StringBuilder output = new StringBuilder();
    SparseSpreadSheet baseSheet = new SparseSpreadSheet();
    SpreadSheetWithMacro model = new SpreadSheetWithMacroImpl(baseSheet);

    MacroSpreadSheetController controller = new MacroSpreadSheetController(
            baseSheet, new StringReader(input.toString()), output);

    controller.control();
    String result = output.toString();
    assertTrue("Should contain first value", result.contains("Value: 5.0"));
    assertTrue("Should contain second value", result.contains("Value: 7.0"));
    assertTrue("Should contain third value", result.contains("Value: 9.0"));
  }

  /**
   * Test average macro functionality through controller.
   */
  @Test
  public void testAverageMacro() {
    StringBuilder input = new StringBuilder();
    input.append("assign-value A 1 10").append(System.lineSeparator());
    input.append("assign-value A 2 20").append(System.lineSeparator());
    input.append("assign-value B 1 30").append(System.lineSeparator());
    input.append("assign-value B 2 40").append(System.lineSeparator());
    input.append("average A 1 B 2 C 1").append(System.lineSeparator());
    input.append("print-value C 1").append(System.lineSeparator());
    input.append("q").append(System.lineSeparator());

    StringBuilder output = new StringBuilder();
    SparseSpreadSheet baseSheet = new SparseSpreadSheet();
    SpreadSheetWithMacro model = new SpreadSheetWithMacroImpl(baseSheet);

    MacroSpreadSheetController controller = new MacroSpreadSheetController(
            baseSheet, new StringReader(input.toString()), output);

    controller.control();
    String result = output.toString();
    assertTrue("Should contain average value", result.contains("Value: 25.0"));
  }
}